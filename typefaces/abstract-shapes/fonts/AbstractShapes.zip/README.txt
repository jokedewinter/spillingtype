©2022 Spilling Type.

Abstract Shapes is a set of two free fonts (Regular and RegularAlt) for you to use for whatever you wish. It can be personal or commercial. It can be online or offline (print). You can share the files with friends, family or your favourite aliens as long as you include this README file as well.

You can not offer these fonts as a download, sell them or include them in any kind of software collection without asking my permission first in writing. Spilling Type will not be liable for any damages arising out of the use or inability to use these fonts. 

Abstract Shapes was designed for the 2022 edition of 36 Days of Type. I aimed to create something reminiscent of hieroglyphs. Or other ancient scripts like the Phoenician alphabet. It needed to have enough legibility to make it useable, but is not intended for use in body text. It works well as a headline in an appropriate setting. 

The fonts has a limited character set with the lowercase glyphs matched to the uppercase glyphs. 
Letters: A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z
Numbers: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
Symbol: & 
Punctuation: period, comma, colon, semicolon, ellipsis, exclamation mark, question mark, quote left, quote right, double quote, single quote.

I look forward to see how you will use it. Let me know. 

https://spillingtype.com
https://www.instagram.com/spillingtype/
spillingtype@gmail.com